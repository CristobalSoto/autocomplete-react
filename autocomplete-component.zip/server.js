const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', function connection(ws) {
    console.log('A new client connected.');
    ws.on('message', function incoming(message) {
        console.log('Received: %s', message);
    });

    const sendCompletion = () => {
        const completionPercentage = Math.floor(Math.random() * 100);
        ws.send(JSON.stringify({ completion: completionPercentage }));
    };

    const interval = setInterval(sendCompletion, 1000);

    ws.on('close', () => {
        clearInterval(interval);
    });
});

console.log('WebSocket server is running on ws://localhost:8080');
